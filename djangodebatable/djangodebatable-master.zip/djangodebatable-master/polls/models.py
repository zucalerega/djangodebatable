from django.db import models
from django.urls import reverse

# Create your models here.
#class Poll(models.Model):
